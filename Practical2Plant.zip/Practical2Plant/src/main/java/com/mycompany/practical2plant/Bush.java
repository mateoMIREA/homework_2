/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical2plant;

/**
 *
 * @author М_З_А
 */
public class Bush extends SmallPlant{
    private double leafSize;

    public Bush(double leafSize, double rootLength, String climateZone, String name, int age, String area) {
        super(rootLength, climateZone, name, age, area);
        this.leafSize = leafSize;
    }

    public double getLeafSize() {
        return leafSize;
    }

    public void setLeafSize(double leafSize) {
        if (leafSize <= 0){
        System.out.println("Введены неверные данные");}
        else{
        this.leafSize = leafSize;}
    }
    
    @Override
    public String toString() {
    return "Plant = {" + " Название: " + getName() + " Возраст: " + getAge() + " Зона произрастания: " + getArea() + " Длина корня: " + getRootLength() + " Климатическая зона: " + getClimateZone() + " Длина листьев: " + getLeafSize() + " }";
    }
    
}
