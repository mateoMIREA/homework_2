/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical2plant;

/**
 *
 * @author М_З_А
 */
public class Fruitful extends SmallPlant{
    private double fruitSize;

    public Fruitful(double fruitSize, double rootLength, String climateZone, String name, int age, String area) {
        super(rootLength, climateZone, name, age, area);
        this.fruitSize = fruitSize;
    }

    public double getFruitSize() {
        return fruitSize;
    }

    public void setFruitSize(double fruitSize) {
        this.fruitSize = fruitSize;
    }
    
    @Override
    public String toString() {
    return "Plant = {" + " Название: " + getName() + " Возраст: " + getAge() + " Зона произрастания: " + getArea() + " Длина корня: " + getRootLength() + " Климатическая зона: " + getClimateZone() + " Размер фруктов (длина): " + getFruitSize() + " }";
    }
    
}
