/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical2plant;
import java.util.Scanner;
/**
 *
 * @author М_З_А
 */


public class Practical2Plant {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Практическая работа №2, вариант 4, Новиков М.С., РИБО-01-21");
        System.out.println("Введите название растения: ");
        String nm = scan.next();
        System.out.println("Введите возраст растения: ");
        int ag = scan.nextInt();
        System.out.println("Введите зону произрастания растения: ");
        String ar = scan.next();
        System.out.println("Выберите цифру: 1 - Дерево, 2 - Небольшое растение");
        int a = scan.nextInt();
            if (a == 1) {
                System.out.println("Введите тип: ");
                String ty = scan.next();
                System.out.println("Введите высоту: ");
                double hg = scan.nextDouble();
                System.out.println("Выберите цифру: 1 - Фруктовое дерево, 2 - Не фруктовое дерево");
                int i = scan.nextInt();
                    if (i == 1) {
                        System.out.println("Введите название плодов: ");
                        String fN = scan.next();
                        Fruit plant1 = new Fruit(fN, ty, hg, nm, ag, ar);
                        System.out.println(plant1.toString());
                }
                    else {
                    System.out.println("Введите цвет коры: ");
                    String bc = scan.next();
                    NotFruity plant2 = new NotFruity(bc, ty, hg, nm, ag, ar);
                    System.out.println(plant2.toString());
                    }
            }else {
            System.out.println("Введите длину корня: ");
            int rL = scan.nextInt();
            System.out.println("Введите климатическую зону, где находится растение: ");
            String cZ = scan.next();
            System.out.println("Выберите цифру: 1 - Куст, 2 - плодовое растение, 3 - цветок");
            int b = scan.nextInt();
            switch (b) {
                case 1:
                    System.out.println("Введите длину листьев: ");
                    double lS = scan.nextDouble();
                    Bush plant3 = new Bush(lS, rL, cZ, nm, ag, ar);
                    System.out.println(plant3.toString());
                    break;
                case 2:
                    System.out.println("Введите размер фруктов: ");
                    double fS = scan.nextDouble();
                    Fruitful plant4 = new Fruitful(fS, rL, cZ, nm, ag, ar);
                    System.out.println(plant4.toString());
                    break;
                default:
                    System.out.println("Введите цвет цветка: ");
                    String clr = scan.next();
                    Flower plant5 = new Flower(clr, rL, cZ, nm, ag, ar);
                    System.out.println(plant5.toString());
                    break;
            }
            }
            }
            
}