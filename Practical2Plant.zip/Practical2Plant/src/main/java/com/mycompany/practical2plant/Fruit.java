/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical2plant;

/**
 *
 * @author М_З_А
 */
public class Fruit extends Tree{
    private String fruitName;

    public Fruit(String fruitName, String type, double height, String name, int age, String area) {
        super(type, height, name, age, area);
        this.fruitName = fruitName;
    }

    public String getFruitName() {
        return fruitName;
    }

    public void setFruitName(String fruitName) {
        this.fruitName = fruitName;
    }
    
    @Override
    public String toString() {
    return "Plant = {" + " Название: " + getName() + " Возраст: " + getAge() + " Зона произрастания: " + getArea() + " Тип: " + getType() + " Высота: " + getHeight() + " Название плодов: " + getFruitName() + " }";
    }
    
}
